export interface Application {
  id: number;

  applicantName: string;

  submittedDate: string;

  applicationStatus: string;
}
