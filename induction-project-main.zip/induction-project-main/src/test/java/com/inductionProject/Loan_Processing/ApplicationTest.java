package com.inductionProject.Loan_Processing;

import com.inductionProject.Loan_Processing.entity.Application;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ApplicationTest {

	@Test
	void testGettersAndSetters() {
		Application application = new Application();

		Long id = 1L;
		String firstName = "John";
		String middleName = "A.";
		String lastName = "Doe";
		LocalDate dateOfBirth = LocalDate.of(1990, 1, 1);
		String maritalStatus = "Single";
		String ssnNumber = "123-45-6789";
		BigDecimal loanAmount = new BigDecimal("5000");
		String loanPurpose = "Personal";
		String description = "Loan for personal expenses";
		String addressLine1 = "123 Main St";
		String addressLine2 = "Apt 4B";
		String city = "Anytown";
		String state = "CA";
		String postalCode = "12345";
		String homePhone = "123-456-7890";
		String officePhone = "098-765-4321";
		String mobile = "111-222-3333";
		String email = "johndoe@example.com";
		String employerName = "ABC Corp";
		BigDecimal annualSalary = new BigDecimal("60000");
		String employerAddress = "456 Corporate Blvd";
		String employerPostalCode = "200";
		String employerCity = "Big City";
		String employerState = "NY";
		Integer workExperienceYears = 4;
		Integer workExperienceMonths=2;
		String designation = "Manager";
		Double score = 750.0;
		String declineReason = "None";
		String applicationStatus = "Approved";
		LocalDateTime submittedDate = LocalDateTime.of(2023, 7, 29, 10, 0);

		application.setId(id);
		application.setFirstName(firstName);
		application.setMiddleName(middleName);
		application.setLastName(lastName);
		application.setDateOfBirth(dateOfBirth);
		application.setMaritalStatus(maritalStatus);
		application.setSsnNumber(ssnNumber);
		application.setLoanAmount(loanAmount);
		application.setLoanPurpose(loanPurpose);
		application.setDescription(description);
		application.setAddressLine1(addressLine1);
		application.setAddressLine2(addressLine2);
		application.setCity(city);
		application.setState(state);
		application.setPostalCode(postalCode);
		application.setHomePhone(homePhone);
		application.setOfficePhone(officePhone);
		application.setMobile(mobile);
		application.setEmail(email);
		application.setEmployerName(employerName);
		application.setAnnualSalary(annualSalary);
		application.setEmployerAddress(employerAddress);
		application.setEmployerPostalCode(employerPostalCode);
		application.setEmployerCity(employerCity);
		application.setEmployerState(employerState);
		application.setworkExperienceYears(workExperienceYears);
		application.setDesignation(designation);
		application.setScore(score);
		application.setDeclineReason(declineReason);
		application.setApplicationStatus(applicationStatus);
		application.setSubmittedDate(submittedDate);

		assertEquals(id, application.getId());
		assertEquals(firstName, application.getFirstName());
		assertEquals(middleName, application.getMiddleName());
		assertEquals(lastName, application.getLastName());
		assertEquals(dateOfBirth, application.getDateOfBirth());
		assertEquals(maritalStatus, application.getMaritalStatus());
		assertEquals(ssnNumber, application.getSsnNumber());
		assertEquals(loanAmount, application.getLoanAmount());
		assertEquals(loanPurpose, application.getLoanPurpose());
		assertEquals(description, application.getDescription());
		assertEquals(addressLine1, application.getAddressLine1());
		assertEquals(addressLine2, application.getAddressLine2());
		assertEquals(city, application.getCity());
		assertEquals(state, application.getState());
		assertEquals(postalCode, application.getPostalCode());
		assertEquals(homePhone, application.getHomePhone());
		assertEquals(officePhone, application.getOfficePhone());
		assertEquals(mobile, application.getMobile());
		assertEquals(email, application.getEmail());
		assertEquals(employerName, application.getEmployerName());
		assertEquals(annualSalary, application.getAnnualSalary());
		assertEquals(employerAddress, application.getEmployerAddress());
		assertEquals(employerPostalCode, application.getEmployerPostalCode());
		assertEquals(employerCity, application.getEmployerCity());
		assertEquals(employerState, application.getEmployerState());
		assertEquals(workExperienceYears, application.getworkExperienceYears());
		assertEquals(workExperienceMonths,application.getworkExperienceMonths());
		assertEquals(designation, application.getDesignation());
		assertEquals(score, application.getScore());
		assertEquals(declineReason, application.getDeclineReason());
		assertEquals(applicationStatus, application.getApplicationStatus());
		assertEquals(submittedDate, application.getSubmittedDate());
	}
}

