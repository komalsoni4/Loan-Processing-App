package com.inductionProject.Loan_Processing;

import com.inductionProject.Loan_Processing.controller.ApplicationController;
import com.inductionProject.Loan_Processing.dto.ApplicationSummaryDTO;
import com.inductionProject.Loan_Processing.entity.Application;
import com.inductionProject.Loan_Processing.service.ApplicationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.time.LocalDateTime;


import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class ApplicationControllerTest {

    @Mock
    private ApplicationService service;

    @InjectMocks
    private ApplicationController controller;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetApplicationSummaries() {
        Long id = 1L;
        String applicantName = "John Doe";
        LocalDateTime submittedDate = LocalDateTime.now();
        String applicationStatus = "Pending";
        ApplicationSummaryDTO summary = new ApplicationSummaryDTO(id, applicantName, submittedDate, applicationStatus);

        List<ApplicationSummaryDTO> summaries = Collections.singletonList(summary);
        when(service.getApplicationSummaries()).thenReturn(summaries);

        List<ApplicationSummaryDTO> result = controller.getApplicationSummaries();
        assertEquals(summaries, result);
        verify(service, times(1)).getApplicationSummaries();
    }

    @Test
    void testGetAllApplicants() {
        List<Application> applicants = Collections.singletonList(new Application());
        when(service.getAllApplicants()).thenReturn(applicants);

        List<Application> result = controller.getAllApplicants();
        assertEquals(applicants, result);
        verify(service, times(1)).getAllApplicants();
    }

    @Test
    void testGetApplicantById() {
        Application applicant = new Application();
        when(service.getApplicantById(1L)).thenReturn(applicant);

        Application result = controller.getApplicantById(1L);
        assertEquals(applicant, result);
        verify(service, times(1)).getApplicantById(1L);
    }

    @Test
    void testCreateApplicant() {
        Application applicant = new Application();
        when(service.createApplicant(applicant)).thenReturn(applicant);

        Application result = controller.createApplicant(applicant);
        assertEquals(applicant, result);
        verify(service, times(1)).createApplicant(applicant);
    }

    @Test
    void testDeleteApplicant() {
        doNothing().when(service).deleteApplicant(1L);

        controller.deleteApplicant(1L);
        verify(service, times(1)).deleteApplicant(1L);
    }
}
