package com.inductionProject.Loan_Processing;

import com.inductionProject.Loan_Processing.dto.ApplicationSummaryDTO;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class ApplicationSummaryDTOTest {

    @Test
    void testConstructorAndGetters() {
        Long id = 1L;
        String applicantName = "John Doe";
        LocalDateTime submittedDate = LocalDateTime.of(2023, 7, 29, 10, 0);
        String applicationStatus = "Pending";

        ApplicationSummaryDTO dto = new ApplicationSummaryDTO(id, applicantName, submittedDate, applicationStatus);

        assertEquals(id, dto.getId());
        assertEquals(applicantName, dto.getApplicantName());
        assertEquals(submittedDate, dto.getSubmittedDate());
        assertEquals(applicationStatus, dto.getApplicationStatus());
    }

    @Test
    void testSetters() {
        ApplicationSummaryDTO dto = new ApplicationSummaryDTO(null, null, null, null);

        Long id = 2L;
        String applicantName = "Jane Smith";
        LocalDateTime submittedDate = LocalDateTime.of(2023, 7, 30, 11, 0);
        String applicationStatus = "Approved";

        dto.setId(id);
        dto.setApplicantName(applicantName);
        dto.setSubmittedDate(submittedDate);
        dto.setApplicationStatus(applicationStatus);

        assertEquals(id, dto.getId());
        assertEquals(applicantName, dto.getApplicantName());
        assertEquals(submittedDate, dto.getSubmittedDate());
        assertEquals(applicationStatus, dto.getApplicationStatus());
    }
}

