package com.inductionProject.Loan_Processing;

import com.inductionProject.Loan_Processing.dto.ApplicationSummaryDTO;
import com.inductionProject.Loan_Processing.entity.Application;
import com.inductionProject.Loan_Processing.repository.Crud;
import com.inductionProject.Loan_Processing.service.ApplicationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

public class ApplicationServiceTest {

    @Mock
    private Crud repository;

    @InjectMocks
    private ApplicationService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetApplicationSummaries() {
        Application application = new Application();
        application.setId(1L);
        application.setFirstName("John");
        application.setMiddleName("A.");
        application.setLastName("Doe");
        application.setSubmittedDate(LocalDateTime.of(2023, 7, 29, 10, 0));
        application.setApplicationStatus("Approved");

        when(repository.findAll()).thenReturn(Arrays.asList(application));

        List<ApplicationSummaryDTO> summaries = service.getApplicationSummaries();
        assertEquals(1, summaries.size());
        ApplicationSummaryDTO summary = summaries.get(0);
        assertEquals("John A. Doe", summary.getApplicantName());
        assertEquals("Approved", summary.getApplicationStatus());

        verify(repository, times(1)).findAll();
    }

    @Test
    void testGetAllApplicants() {
        Application application1 = new Application();
        Application application2 = new Application();
        when(repository.findAll()).thenReturn(Arrays.asList(application1, application2));

        List<Application> applicants = service.getAllApplicants();
        assertEquals(2, applicants.size());

        verify(repository, times(1)).findAll();
    }

    @Test
    void testGetApplicantById() {
        Application application = new Application();
        application.setId(1L);
        when(repository.findById(1L)).thenReturn(Optional.of(application));

        Application result = service.getApplicantById(1L);
        assertEquals(application, result);

        verify(repository, times(1)).findById(1L);
    }

    @Test
    void testCreateApplicant() {
        Application application = new Application();
        application.setId(1L);
        when(repository.save(application)).thenReturn(application);

        Application result = service.createApplicant(application);
        assertEquals(application, result);

        verify(repository, times(1)).save(application);
    }

    @Test
    void testDeleteApplicant() {
        doNothing().when(repository).deleteById(1L);

        service.deleteApplicant(1L);
        verify(repository, times(1)).deleteById(1L);
    }
}

