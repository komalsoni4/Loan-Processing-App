package com.inductionProject.Loan_Processing.repository;

import com.inductionProject.Loan_Processing.entity.Application;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Repository
public interface Crud extends JpaRepository<Application,Long> {

   Optional<Application> findBySsnNumber(Long ssnNumber);
}
