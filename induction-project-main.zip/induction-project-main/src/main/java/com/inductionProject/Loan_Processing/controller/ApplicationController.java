package com.inductionProject.Loan_Processing.controller;

import com.inductionProject.Loan_Processing.dto.ApplicationSummaryDTO;
import com.inductionProject.Loan_Processing.entity.Application;
import com.inductionProject.Loan_Processing.repository.BureaDataRepository;
import com.inductionProject.Loan_Processing.repository.Crud;
import com.inductionProject.Loan_Processing.service.ApplicationService;
import com.inductionProject.Loan_Processing.service.BusinessLogic;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.*;

import com.inductionProject.Loan_Processing.service.BureaDataService;

import java.util.List;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api/loan_applicants")
//@Component
public class ApplicationController {

    private final ApplicationService service;

    @Autowired
    private BusinessLogic businessLogic;

    @Autowired
    public ApplicationController(ApplicationService service)
    {
        this.service = service;
    }

    @GetMapping("/view_apps")
    public List<ApplicationSummaryDTO> getApplicationSummaries() {
        return service.getApplicationSummaries();
    }

    @GetMapping("/view_application")
    public List<Application> getAllApplicants() {
        return service.getAllApplicants();
    }

    @GetMapping("view_application/{id}")
    public Application getApplicantById(@PathVariable Long id) {
        return service.getApplicantById(id);
    }

    @PostMapping
    public Application createApplicant(@RequestBody Application applicant) {
        // here ::
        Long ssnNumber = applicant.getSsnNumber();
        Long id = applicant.getId();
        System.out.println("ssnNumber : " +  ssnNumber);
        double creditScore = businessLogic.calcScore(ssnNumber, applicant);
        //

        //
        applicant.setScore(creditScore);
        String declineReason = creditScore >=600 ? "None" : "Low Credit Score";
        String applicationStatus = creditScore>=600 ? "Approved" : "Declined";
        applicant.setDeclineReason(declineReason);
        applicant.setApplicationStatus(applicationStatus);
//        applicationRepository.save(application);
//        return applicationRepository.getById(id);
        return service.createApplicant(applicant);
    }
}
