package com.inductionProject.Loan_Processing.repository;

import com.inductionProject.Loan_Processing.entity.Application;
import com.inductionProject.Loan_Processing.entity.BureauData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BureaDataRepository extends JpaRepository<BureauData,Long> {

}
