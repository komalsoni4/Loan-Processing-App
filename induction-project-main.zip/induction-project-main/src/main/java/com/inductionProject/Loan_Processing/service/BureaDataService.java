package com.inductionProject.Loan_Processing.service;

import com.inductionProject.Loan_Processing.entity.Application;
import com.inductionProject.Loan_Processing.entity.BureauData;
import com.inductionProject.Loan_Processing.repository.BureaDataRepository;
import com.inductionProject.Loan_Processing.repository.Crud;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class BureaDataService {

    @Autowired
    private Crud applicationRepository;

    @Autowired
    private BureaDataRepository bureauDataRepository;

//    public void calculateScore(Long ssnNumber) {
//        Application application = applicationRepository.findBySsnNumber(ssnNumber).orElseThrow();
//        BureauData bureauData = bureauDataRepository.findById(ssnNumber).orElseThrow();
//
//
//
//        // Update application with score and description
//       application.setScore(score);
//       application.setDescription(description);
//
//        applicationRepository.save(application);
//    }

    public List<BureauData> findAll() {
        return bureauDataRepository.findAll();
    }

    public BureauData findById(Long id) {
        return bureauDataRepository.findById(id).orElse(null);
    }

    public BureauData save(BureauData bureauData) {
        return bureauDataRepository.save(bureauData);
    }

    public void deleteById(Long id) {
        bureauDataRepository.deleteById(id);
    }

}
